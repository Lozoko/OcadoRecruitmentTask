package structures;

import java.util.Map;

public class Node implements Comparable<Node>{
    private final Position position;
    private float tentativeDistance;
    private Position parentPosition;
    private boolean visited;
    private Map<Position, Float> neighbors;

    public Node(Position position, float tentativeDistance, Position parentPosition) {
        this.position = position;
        this.tentativeDistance = tentativeDistance;
        this.parentPosition = parentPosition;
        this.visited = false;
    }

    public Position getPosition() {
        return position;
    }

    public float getTentativeDistance() {
        return tentativeDistance;
    }

    public void setTentativeDistance(float tentativeDistance) {
        this.tentativeDistance = tentativeDistance;
    }

    public Position getParentPosition() {
        return parentPosition;
    }

    public void setParentPosition(Position parentPosition) {
        this.parentPosition = parentPosition;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    public Map<Position, Float> getNeighbors() {
        return neighbors;
    }

    public void setNeighbors(Map<Position, Float> neighbors) {
        this.neighbors = neighbors;
    }

    @Override
    public int compareTo(Node node) {
        return Float.compare(this.getTentativeDistance(), node.getTentativeDistance());
    }
}
