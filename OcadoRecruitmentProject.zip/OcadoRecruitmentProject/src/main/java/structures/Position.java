package structures;

public final class Position {
    private final Integer X, Y;

    public Position(Integer Y, Integer X) {
        this.X = X;
        this.Y = Y;
    }

    public Integer getX() {
        return X;
    }

    public Integer getY() {
        return Y;
    }

    @Override
    public int hashCode() {
        return X * 31 + Y;
    }

    @Override
    public boolean equals(Object obj) {
        return (obj instanceof Position) && ((Position) obj).getX().equals(getX())
                && ((Position) obj).getY().equals(getY());
    }

    @Override
    public String toString(){
        return X + " " + Y;
    }
}
