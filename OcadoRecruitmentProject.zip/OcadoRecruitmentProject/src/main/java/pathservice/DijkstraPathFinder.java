package pathservice;

import structures.Node;
import structures.Position;

import java.util.Map;
import java.util.PriorityQueue;

public class DijkstraPathFinder {
    private final Node[][] nodeMatrix;

    public DijkstraPathFinder(Node[][] nodeMatrix){
        this.nodeMatrix = nodeMatrix;
    }

    public Node[][] findPaths(Position startingPosition){
        PriorityQueue<Node> queue = new PriorityQueue<>();
        for (Node[] matrix : nodeMatrix) {
            for (int j = 0; j < nodeMatrix[0].length; j++) {
                if (matrix[j] != null && !startingPosition.equals(matrix[j].getPosition()))
                    queue.add(new Node(matrix[j].getPosition(), matrix[j].getTentativeDistance(), null));
            }
        }
        nodeMatrix[startingPosition.getY()][startingPosition.getX()].setTentativeDistance(0);
        Node matrixNode = nodeMatrix[startingPosition.getY()][startingPosition.getX()];
        queue.add(new Node(matrixNode.getPosition(), matrixNode.getTentativeDistance(), null));

        while(!queue.isEmpty()){
            Node tmpNode = queue.poll();
            tmpNode = nodeMatrix[tmpNode.getPosition().getY()][tmpNode.getPosition().getX()];
            if(!tmpNode.isVisited()){
                for(Map.Entry<Position, Float> neighbor: tmpNode.getNeighbors().entrySet()){
                    matrixNode = nodeMatrix[neighbor.getKey().getY()][neighbor.getKey().getX()];
                    if(matrixNode.getTentativeDistance() > tmpNode.getTentativeDistance() + neighbor.getValue()){
                        Node node = new Node(matrixNode.getPosition(), matrixNode.getTentativeDistance(), null);
                        node.setTentativeDistance(tmpNode.getTentativeDistance() + neighbor.getValue());
                        matrixNode.setTentativeDistance(node.getTentativeDistance());
                        matrixNode.setParentPosition(new Position(tmpNode.getPosition().getY(),
                                tmpNode.getPosition().getX()));
                        queue.add(node);
                    }
                }
                tmpNode.setVisited(true);
            }
        }
        return nodeMatrix;
    }


}
