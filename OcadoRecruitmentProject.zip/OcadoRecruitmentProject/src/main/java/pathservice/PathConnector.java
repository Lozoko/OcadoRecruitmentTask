package pathservice;

import Consts.TimeTable;
import structures.Node;
import structures.Position;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class PathConnector {
    private final Node[][] botMatrix;
    private final Node[][] stationMatrix;
    private final int[][] productsPlacement;
    private final char[][] grid;
    private int pathLength;
    private float pathCost;
    private List<Position> path;


    public PathConnector(Node[][] botMatrix, Node[][] stationMatrix, int[][] productsPlacement, char[][] grid) {
        this.botMatrix = botMatrix;
        this.stationMatrix = stationMatrix;
        this.productsPlacement = productsPlacement;
        this.grid = grid;
        this.pathLength = 0;
        this.pathCost = Float.POSITIVE_INFINITY;
        this.path = null;
    }

    public void connectPaths(){
        Position position = null;
        for(int[] productPlace : productsPlacement){
            int x = productPlace[0];
            int y = productPlace[1];
            int n = productPlace[2];
            float botMatrixCost = botMatrix[y][x].getTentativeDistance();
            float stationMatrixCost = stationMatrix[y][x].getTentativeDistance();
            float a = TimeTable.timeTable.get(grid[y][x])[1];
            float b = TimeTable.timeTable.get(grid[y][x])[2];
            float cost = botMatrixCost + stationMatrixCost + a*n + b;
            if(cost < pathCost){
                position =  new Position(y, x);
                pathCost = cost;
            }
        }
        List<Position> botPath = new LinkedList<>();
        List<Position> stationPath = new LinkedList<>();
        Node node = botMatrix[position.getY()][position.getX()];
        while(node.getParentPosition() != null) {
            botPath.add(node.getPosition());
            node = botMatrix[node.getParentPosition().getY()][node.getParentPosition().getX()];
        }
        botPath.add(node.getPosition());
        node = stationMatrix[position.getY()][position.getX()];
        while(node.getParentPosition() != null) {
            stationPath.add(node.getPosition());
            node = stationMatrix[node.getParentPosition().getY()][node.getParentPosition().getX()];
        }
        stationPath.add(node.getPosition());
        pathLength = botPath.size() + stationPath.size() - 2;

        path = new ArrayList<>(botPath.size() + stationPath.size() - 1);
        botPath.remove(0);
        Collections.reverse(botPath);
        path.addAll(botPath);
        path.addAll(stationPath);
    }

    public int getPathLength() {
        return pathLength;
    }

    public float getPathCost() {
        return pathCost;
    }

    public List<Position> getPath() {
        return path;
    }
}
