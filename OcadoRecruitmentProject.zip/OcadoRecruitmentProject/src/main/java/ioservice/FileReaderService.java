package ioservice;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class FileReaderService {
    private final String gridFile;
    private final String jobFile;
    public FileReaderService(String gridFile, String jobFile){
        this.gridFile = gridFile;
        this.jobFile = jobFile;
    }

    public char[][] loadGrid() throws Exception {
        char[][] grid;
        int x, y, n;

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(this.gridFile))) {
            String curReadLine;
            curReadLine = bufferedReader.readLine();
            if (curReadLine == null)
                throw new IOException("Could not read grid file");

            String[] firstLine = curReadLine.split("\\s+");
            if (firstLine.length != 3)
                throw new Exception("Grid file in wrong format");
            x = Integer.parseInt(firstLine[0]);
            y = Integer.parseInt(firstLine[1]);
            n = Integer.parseInt(firstLine[2]);

            grid = new char[y][x];
            char[] gridLine;
            for (int i = 0; i < y; i++) {
                if ((curReadLine = bufferedReader.readLine()) == null)
                    throw new IOException("Could not read grid file");
                gridLine = curReadLine.toCharArray();
                if (gridLine.length != x)
                    throw new Exception("Grid file in wrong format");
                grid[i] = gridLine;
            }
        }
        return grid;
    }

    public int[][] loadChosenProduct(String productName) throws Exception {
        List<List<String>> productsPlacement = new LinkedList<>();
        int y;
        int[][] productsPlacementArray = null;

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(this.gridFile))) {
            String curReadLine;
            curReadLine = bufferedReader.readLine();
            if (curReadLine == null)
                throw new IOException("Could not read grid file");

            String[] firstLine = curReadLine.split("\\s+");
            if (firstLine.length != 3)
                throw new Exception("Grid file in wrong format");
            y = Integer.parseInt(firstLine[1]);
            for (int i = 0; i < y; i++) {
                if ((curReadLine = bufferedReader.readLine()) == null)
                    throw new IOException("Could not read grid file");
            }
            while((curReadLine = bufferedReader.readLine()) != null){
                List<String> productPlacement = new ArrayList<String>(List.of(curReadLine.split("\\s+")));
                if(productPlacement.size() != 4){
                    throw new Exception("Grid file in wrong format");
                }
                if(productPlacement.get(0).equals(productName))
                    productsPlacement.add(productPlacement);
            }
            productsPlacementArray = new int[productsPlacement.size()][3];
            int i = 0;
            for(List<String> positions : productsPlacement){
                productsPlacementArray[i][0] = Integer.parseInt(positions.get(1));
                productsPlacementArray[i][1] = Integer.parseInt(positions.get(2));
                productsPlacementArray[i][2] = Integer.parseInt(positions.get(3));
                i++;
            }
        }
        return productsPlacementArray;
    }

    public String[] loadJob() throws Exception {
        String[] jobArray = new String[5];

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(this.jobFile))) {
            String curReadLine;
            curReadLine = bufferedReader.readLine();
            if (curReadLine == null)
                throw new IOException("Could not read grid file");

            String[] firstLine = curReadLine.split("\\s+");
            if (firstLine.length != 2)
                throw new Exception("Grid file in wrong format");
            jobArray[0] = firstLine[0];
            jobArray[1] = firstLine[1];

            curReadLine = bufferedReader.readLine();
            if (curReadLine == null)
                throw new IOException("Could not read grid file");

            String[] secondLine = curReadLine.split("\\s+");
            if (secondLine.length != 2)
                throw new Exception("Grid file in wrong format");
            jobArray[2] = secondLine[0];
            jobArray[3] = secondLine[1];

            curReadLine = bufferedReader.readLine();
            if (curReadLine == null)
                throw new IOException("Could not read grid file");

            String[] thirdLine = curReadLine.split("\\s+");
            if (thirdLine.length != 1)
                throw new Exception("Grid file in wrong format");
            jobArray[4] = thirdLine[0];
        }
        return jobArray;
    }

    public String getGridFile() {
        return gridFile;
    }

    public String getJobFile() {
        return jobFile;
    }
}
