package Consts;

import java.util.*;

public class TimeTable {
    public static Map<Character, float[]> timeTable = new HashMap<Character, float[]>(){{
        put('H', new float[]{0.5f, 3, 4});
        put('B', new float[]{1, 2, 2});
        put('S', new float[]{2, 1, 1});
    }};
}
