import graphservice.GraphCreator;
import ioservice.FileReaderService;
import pathservice.DijkstraPathFinder;
import pathservice.PathConnector;
import structures.Node;
import structures.Position;

public class MainApp {
    public static void main(String[] args) {
        FileReaderService fileReaderService = new FileReaderService(args[0],
                args[1]);
        GraphCreator graphCreator = null;
        char[][] grid = null;
        try {
            grid = fileReaderService.loadGrid();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
        graphCreator = new GraphCreator(grid);

        String[] job = null;
        try {
            job = fileReaderService.loadJob();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }

        DijkstraPathFinder botPathFinder = new DijkstraPathFinder(graphCreator.createGraph());
        Position position = new Position(Integer.parseInt(job[1]), Integer.parseInt(job[0]));
        Node[][] botMatrix = botPathFinder.findPaths(position);

        DijkstraPathFinder stationPathFinder = new DijkstraPathFinder(graphCreator.createGraph());
        position = new Position(Integer.parseInt(job[3]), Integer.parseInt(job[2]));
        Node[][] stationMatrix = stationPathFinder.findPaths(position);

        int[][] productsPlacement = null;
        try {
            productsPlacement = fileReaderService.loadChosenProduct(job[4]);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }

        PathConnector pathConnector = new PathConnector(botMatrix, stationMatrix, productsPlacement, grid);
        pathConnector.connectPaths();

        System.out.println(pathConnector.getPathLength());
        System.out.println(pathConnector.getPathCost());
        for(Position pathPosition : pathConnector.getPath())
            System.out.println(pathPosition);
    }
}
