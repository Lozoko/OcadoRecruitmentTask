package graphservice;

import Consts.TimeTable;
import structures.Node;
import structures.Position;

import java.util.HashMap;
import java.util.Map;

import static java.lang.Math.max;

public class GraphCreator {
    private final char[][] grid;

    public GraphCreator(char[][] grid){
        this.grid = grid;
    }

    public Node[][] createGraph(){
        Node[][] nodeMatrix = new Node[grid.length][grid[0].length];
        for(int i = 0; i < grid.length; i++){
            for(int j = 0; j < grid[0].length; j++){
                if(TimeTable.timeTable.containsKey(grid[i][j])) {
                    Node node = new Node(new Position(i, j), Float.POSITIVE_INFINITY, null);
                    Map<Position, Float> neighbors = new HashMap<Position, Float>();
                    if(i > 0 && TimeTable.timeTable.containsKey(grid[i-1][j])){
                        neighbors.put(new Position(i-1, j),
                                max(TimeTable.timeTable.get(grid[i-1][j])[0], TimeTable.timeTable.get(grid[i][j])[0]));
                    }
                    if(i < grid.length - 1 && TimeTable.timeTable.containsKey(grid[i+1][j])){
                        neighbors.put(new Position(i+1, j),
                                max(TimeTable.timeTable.get(grid[i+1][j])[0], TimeTable.timeTable.get(grid[i][j])[0]));
                    }
                    if(j > 0 && TimeTable.timeTable.containsKey(grid[i][j-1])){
                        neighbors.put(new Position(i, j-1),
                                max(TimeTable.timeTable.get(grid[i][j-1])[0], TimeTable.timeTable.get(grid[i][j])[0]));
                    }
                    if(j < grid[0].length - 1 && TimeTable.timeTable.containsKey(grid[i][j+1])){
                        neighbors.put(new Position(i, j+1),
                                max(TimeTable.timeTable.get(grid[i][j+1])[0], TimeTable.timeTable.get(grid[i][j])[0]));
                    }
                    node.setNeighbors(neighbors);
                    nodeMatrix[i][j] = node;
                }

            }
        }
        return nodeMatrix;
    }
}
