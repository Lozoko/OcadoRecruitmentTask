package ioservice;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;


public class FileReaderServiceTest {
    @Test
    public void FileReaderServiceInitializationTest(){
        String gridFile = "grid-1.txt";
        String jobFile = "job-1.txt";
        FileReaderService fileReaderService = new FileReaderService(gridFile, jobFile);
        Assertions.assertEquals(fileReaderService.getGridFile(), gridFile);
        Assertions.assertEquals(fileReaderService.getJobFile(), jobFile);
    }

    @Test
    public void loadGridTest(){
        String gridFile = "src/test/data/grid-1.txt";
        String jobFile = "src/test/data/job-1.txt";
        FileReaderService fileReaderService = new FileReaderService(gridFile, jobFile);
        char[][] grid = {{'H','H','S','H'},
                {'H','B','H','H'},
                {'H','H','O','S'}};
        char[][] wrongGrid = {{'S','B','S','H'},
                {'H','B','H','H'},
                {'O','O','O','S'}};
        try {
            assertTrue(Arrays.deepEquals(grid, fileReaderService.loadGrid()));
            assertFalse(Arrays.deepEquals(wrongGrid, fileReaderService.loadGrid()));
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Test
    public void loadChosenProduct(){
        String gridFile = "src/test/data/grid-1.txt";
        String jobFile = "src/test/data/job-1.txt";
        FileReaderService fileReaderService = new FileReaderService(gridFile, jobFile);
        int[][] productPosition = {
                {3, 2, 1},
                {0, 2, 2}
        };
        try {
            assertNotNull(fileReaderService.loadChosenProduct("P1"));
        }
        catch (Exception e){
            e.printStackTrace();
        }

        try {
            assertTrue(Arrays.deepEquals(productPosition, fileReaderService.loadChosenProduct("P1")));
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Test
    public void loadJob(){
        String gridFile = "src/test/data/grid-1.txt";
        String jobFile = "src/test/data/job-1.txt";
        FileReaderService fileReaderService = new FileReaderService(gridFile, jobFile);
        String[] jobArray = {"1", "1", "0", "0", "P1"};
        try {
            assertArrayEquals(jobArray, fileReaderService.loadJob());
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}