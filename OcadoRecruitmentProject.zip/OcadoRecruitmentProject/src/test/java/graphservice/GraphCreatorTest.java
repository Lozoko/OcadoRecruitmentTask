package graphservice;

import org.junit.Test;
import structures.Node;
import structures.Position;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GraphCreatorTest {

    @Test
    public void createGraphTest(){
        char[][] grid = {{'B','H'},
                        {'S','O'}};
        Node[][] nodeMatrix = new Node[2][2];
        Node node = new Node(new Position(0, 0), Float.POSITIVE_INFINITY, null);
        Map<Position, Float> neighbors = new HashMap<Position, Float>();
        neighbors.put(new Position(0, 1), 1f);
        neighbors.put(new Position(1, 0), 2f);
        node.setNeighbors(neighbors);
        nodeMatrix[0][0] = node;

        node = new Node(new Position(1, 0), Float.POSITIVE_INFINITY, null);
        neighbors = new HashMap<Position, Float>();
        neighbors.put(new Position(0, 0), 2f);
        node.setNeighbors(neighbors);
        nodeMatrix[1][0] = node;

        node = new Node(new Position(0, 1), Float.POSITIVE_INFINITY, null);
        neighbors = new HashMap<Position, Float>();
        neighbors.put(new Position(0, 0), 1f);
        node.setNeighbors(neighbors);
        nodeMatrix[0][1] = node;

        GraphCreator graphCreator = new GraphCreator(grid);
        Node[][] nodeMatrixTest = graphCreator.createGraph();
        assertEquals(nodeMatrix[0][0].getPosition(), nodeMatrixTest[0][0].getPosition());
        assertEquals(nodeMatrix[0][1].getPosition(), nodeMatrixTest[0][1].getPosition());
        assertEquals(nodeMatrix[1][0].getPosition(), nodeMatrixTest[1][0].getPosition());
        assertNull(nodeMatrixTest[1][1]);

        assertEquals(nodeMatrix[0][0].getTentativeDistance(), nodeMatrixTest[0][0].getTentativeDistance());
        assertEquals(nodeMatrix[0][1].getTentativeDistance(), nodeMatrixTest[0][1].getTentativeDistance());
        assertEquals(nodeMatrix[1][0].getTentativeDistance(), nodeMatrixTest[1][0].getTentativeDistance());

        assertEquals(nodeMatrix[0][0].getNeighbors().get(new Position(0, 1)),
                nodeMatrixTest[0][0].getNeighbors().get(new Position(0, 1)));
        assertEquals(nodeMatrix[0][0].getNeighbors().get(new Position(1, 0)),
                nodeMatrixTest[0][0].getNeighbors().get(new Position(1, 0)));
        assertEquals(nodeMatrix[0][1].getNeighbors().get(new Position(0, 0)),
                nodeMatrixTest[0][1].getNeighbors().get(new Position(0, 0)));
        assertEquals(nodeMatrix[1][0].getNeighbors().get(new Position(0, 0)),
                nodeMatrixTest[1][0].getNeighbors().get(new Position(0, 0)));
    }

}