package structures;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PositionTest {

    @Test
    public void equalsTest(){
        Position pos1 = new Position(0, 1);
        Position pos2 = new Position(0, 1);
        Position pos3 = new Position(1, 1);

        assertTrue(pos1.equals(pos2));
        assertTrue(pos2.equals(pos1));
        assertFalse(pos1.equals(pos3));

        assertEquals(pos1.getX(), pos2.getX());
        assertEquals(pos1.getY(), pos2.getY());

        assertNotEquals(pos1.getY(), pos3.getY());
        assertEquals(pos1.getX(), pos3.getX());
    }

}