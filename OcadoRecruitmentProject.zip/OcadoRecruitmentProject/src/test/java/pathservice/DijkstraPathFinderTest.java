package pathservice;

import graphservice.GraphCreator;
import org.junit.Test;
import structures.Node;
import structures.Position;

import static org.junit.jupiter.api.Assertions.*;

public class DijkstraPathFinderTest {

    @Test
    public void findPathsTest(){
        char[][] grid = {{'B','H'},
                {'S','O'}};
        GraphCreator graphCreator = new GraphCreator(grid);
        Node[][] matrix = graphCreator.createGraph();
        Position startingPosition = new Position(0, 0);
        DijkstraPathFinder dijkstraPathFinder = new DijkstraPathFinder(matrix);
        Node[][] pathMatrixTest = dijkstraPathFinder.findPaths(startingPosition);
        Node[][] pathMatrix = graphCreator.createGraph();
        pathMatrix[0][0].setTentativeDistance(0);
        pathMatrix[0][0].setVisited(true);
        pathMatrix[0][1].setTentativeDistance(1);
        pathMatrix[0][1].setVisited(true);
        pathMatrix[0][1].setParentPosition(new Position(0, 0));
        pathMatrix[1][0].setTentativeDistance(2);
        pathMatrix[1][0].setVisited(true);
        pathMatrix[1][0].setParentPosition(new Position(0, 0));

        assertEquals(pathMatrix[0][0].getTentativeDistance(), pathMatrixTest[0][0].getTentativeDistance());
        assertEquals(pathMatrix[0][1].getTentativeDistance(), pathMatrixTest[0][1].getTentativeDistance());
        assertEquals(pathMatrix[1][0].getTentativeDistance(), pathMatrixTest[1][0].getTentativeDistance());

        assertTrue(pathMatrixTest[0][0].isVisited());
        assertTrue(pathMatrixTest[0][1].isVisited());
        assertTrue(pathMatrixTest[1][0].isVisited());

        assertEquals(pathMatrix[0][1].getParentPosition(), pathMatrixTest[0][1].getParentPosition());
        assertEquals(pathMatrix[1][0].getParentPosition(), pathMatrixTest[1][0].getParentPosition());

        assertNull(pathMatrixTest[0][0].getParentPosition());

        assertNull(pathMatrixTest[1][1]);
    }

}