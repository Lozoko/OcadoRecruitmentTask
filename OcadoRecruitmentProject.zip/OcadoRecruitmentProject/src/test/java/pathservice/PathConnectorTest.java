package pathservice;

import graphservice.GraphCreator;
import org.junit.Test;
import structures.Node;
import structures.Position;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class PathConnectorTest {

    @Test
    public void connectPathsTest(){
        char[][] grid = {{'B','H'},
                {'S','B'}};
        GraphCreator graphCreator = new GraphCreator(grid);
        DijkstraPathFinder dijkstraPathFinderBot = new DijkstraPathFinder(graphCreator.createGraph());
        DijkstraPathFinder dijkstraPathFinderStation = new DijkstraPathFinder(graphCreator.createGraph());
        Node[][] botMatrix = dijkstraPathFinderBot.findPaths(new Position(0, 0));
        Node[][] stationMatrix = dijkstraPathFinderStation.findPaths(new Position(1, 0));
        int[][] productPlacement = new int[1][3];
        productPlacement[0][0] = 1;
        productPlacement[0][1] = 1;
        productPlacement[0][2] = 1;
        PathConnector pathConnector = new PathConnector(botMatrix, stationMatrix, productPlacement, grid);
        float cost = 8f;
        int pathLength = 3;
        List<Position> path = new ArrayList<Position>(4);
        path.add(new Position(0, 0));
        path.add(new Position(0, 1));
        path.add(new Position(1, 1));
        path.add(new Position(1, 0));
        pathConnector.connectPaths();

        assertEquals(cost, pathConnector.getPathCost());
        assertEquals(pathLength, pathConnector.getPathLength());

        assertEquals(path, pathConnector.getPath());
    }

}